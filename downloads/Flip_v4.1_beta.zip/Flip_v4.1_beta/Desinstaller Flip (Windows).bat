@echo off
rmdir /s /q "%APPDATA%\Adobe\CEP\extensions\com.flip.aepanel"
echo Flip a ete desinstalle. Redemarre After Effects.
pause
