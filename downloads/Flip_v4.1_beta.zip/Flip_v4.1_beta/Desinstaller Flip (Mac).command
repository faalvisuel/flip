#!/bin/bash
rm -rf "$HOME/Library/Application Support/Adobe/CEP/extensions/com.flip.aepanel"
echo "Flip a ete desinstalle. Redemarre After Effects."
read -n 1 -s -r -p "Appuie sur une touche pour fermer" || true
