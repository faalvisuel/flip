#!/bin/bash
# Installe le plugin Flip pour After Effects (macOS)
cd "$(dirname "$0")"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.flip.aepanel"
echo "Installation de Flip..."
if [ ! -f "Flip.zxp" ]; then echo "Flip.zxp introuvable a cote de cet installeur."; read -n 1 -s -r -p "Appuie sur une touche pour fermer"; exit 1; fi
rm -rf "$DEST"
mkdir -p "$DEST"
/usr/bin/unzip -q -o "Flip.zxp" -d "$DEST"
if [ -f "$DEST/CSXS/manifest.xml" ]; then
  echo ""
  echo "Flip est installe."
  echo "Redemarre After Effects, puis ouvre : Fenetre > Extensions > Flip"
else
  echo "Echec de l'installation."
fi
echo ""
read -n 1 -s -r -p "Appuie sur une touche pour fermer" || true
