/*
    =====================================================================
     FLIP v2.0 - After Effects (ScriptUI Panel)
     Paysage <-> Portrait sans perte d'information.
    ---------------------------------------------------------------------
     Installation :
       Copier Flip.jsx dans le dossier "Scripts/ScriptUI Panels" d'After
       Effects, relancer AE, puis Fenêtre > Flip.jsx.
       (Ou : Fichier > Scripts > Exécuter le fichier de script...)

     Méthode "Réorganiser" (par défaut) :
       1. Les fonds unis (solides, calques d'effets) sont étirés pour
          couvrir le nouveau cadre.
       2. Les médias plein écran (vidéo, image, précomp, forme) sont
          ajustés EN ENTIER (rien n'est coupé), avec une copie floutée
          derrière en option.
       3. Les autres éléments sont regroupés en blocs (colonnes) d'après
          leur position, puis les blocs sont empilés verticalement,
          centrés et mis à l'échelle pour tenir dans la zone de sécurité.
          Les animations (keyframes) sont conservées.

     Méthode "Ajuster tout" :
       Nouvelle comp contenant la comp d'origine entière, centrée, avec
       une copie floutée en fond.
    =====================================================================
*/

(function FlipPanel(thisObj) {

    var NAME = "Flip";
    var VERSION = "4.1";

    var FORMATS = [
        { label: "Auto (inverser largeur / hauteur)", w: 0, h: 0 },
        { label: "9:16 - 1080 x 1920 (Reels, TikTok, Shorts)", w: 1080, h: 1920 },
        { label: "4:5 - 1080 x 1350 (Feed Instagram)", w: 1080, h: 1350 },
        { label: "1:1 - 1080 x 1080 (Carré)", w: 1080, h: 1080 },
        { label: "16:9 - 1920 x 1080 (Paysage)", w: 1920, h: 1080 }
    ];

    var BG_MODES = [
        "Ajuster entier + copie floutée derrière",
        "Ajuster entier (sans fond flou)",
        "Remplir le cadre (peut couper les bords)"
    ];

    var LOG = [];
    var LOG_PATH = null;
    function log(s) { LOG.push(s); }

    function writeLog() {
        try {
            var f = new File(LOG_PATH || (Folder.userData.fsName + "/Flip_log.txt"));
            f.encoding = "UTF-8";
            f.lineFeed = "Unix";
            if (f.open("w")) { f.write(LOG.join("\n")); f.close(); }
        } catch (e) {}
    }

    /* ------------------------------------------------------------------
       Outils
    ------------------------------------------------------------------ */

    function copyArr(v) {
        var o = [];
        for (var i = 0; i < v.length; i++) o.push(v[i]);
        return o;
    }

    function refTime(L, comp) {
        var a = Math.max(Math.min(L.inPoint, L.outPoint), 0);
        var b = Math.min(Math.max(L.inPoint, L.outPoint), comp.duration);
        if (b <= a) return Math.max(0, Math.min(comp.time, comp.duration));
        return (a + b) / 2;
    }

    function getPos(L, t) {
        var tr = L.transform;
        if (tr.position.dimensionsSeparated) {
            return [tr.xPosition.valueAtTime(t, false), tr.yPosition.valueAtTime(t, false)];
        }
        return tr.position.valueAtTime(t, false);
    }

    // Boîte englobante du calque (sans parent) dans l'espace de la comp.
    function getBounds(L, t) {
        var r = L.sourceRectAtTime(t, false);
        var tr = L.transform;
        var a = tr.anchorPoint.valueAtTime(t, false);
        var p = getPos(L, t);
        var sc = tr.scale.valueAtTime(t, false);
        var rot = 0;
        try { rot = L.threeDLayer ? tr.zRotation.valueAtTime(t, false) : tr.rotation.valueAtTime(t, false); } catch (e) {}
        var rad = rot * Math.PI / 180, c = Math.cos(rad), s = Math.sin(rad);
        var pts = [[r.left, r.top], [r.left + r.width, r.top],
                   [r.left, r.top + r.height], [r.left + r.width, r.top + r.height]];
        var l = 1e9, tp = 1e9, rt = -1e9, bt = -1e9;
        for (var j = 0; j < 4; j++) {
            var x = (pts[j][0] - a[0]) * sc[0] / 100;
            var y = (pts[j][1] - a[1]) * sc[1] / 100;
            var X = p[0] + x * c - y * s;
            var Y = p[1] + x * s + y * c;
            if (X < l) l = X; if (X > rt) rt = X;
            if (Y < tp) tp = Y; if (Y > bt) bt = Y;
        }
        return { l: l, t: tp, r: rt, b: bt, w: Math.max(rt - l, 1), h: Math.max(bt - tp, 1) };
    }

    function setVal(prop, v) {
        if (prop.numKeys === 0) prop.setValue(v);
        else prop.setValueAtTime(prop.keyTime(1), v);
    }

    // Applique fn à la valeur statique ou à chaque keyframe.
    function mapProp(prop, fn, tanK) {
        var n = prop.numKeys;
        if (n === 0) {
            prop.setValue(fn(prop.value));
            return;
        }
        for (var i = 1; i <= n; i++) {
            prop.setValueAtKey(i, fn(prop.keyValue(i)));
            if (tanK !== undefined && prop.isSpatial) {
                try {
                    var ti = copyArr(prop.keyInSpatialTangent(i));
                    var to = copyArr(prop.keyOutSpatialTangent(i));
                    for (var j = 0; j < 2; j++) { ti[j] *= tanK; to[j] *= tanK; }
                    prop.setSpatialTangentsAtKey(i, ti, to);
                } catch (e) {}
            }
        }
    }

    // Le point (ox,oy) va en (nx,ny), tout est mis à l'échelle k (uniforme).
    function transformLayer(L, ox, oy, nx, ny, k) {
        var tr = L.transform;
        if (tr.position.dimensionsSeparated) {
            mapProp(tr.xPosition, function (v) { return nx + (v - ox) * k; });
            mapProp(tr.yPosition, function (v) { return ny + (v - oy) * k; });
        } else {
            mapProp(tr.position, function (v) {
                var o = copyArr(v);
                o[0] = nx + (v[0] - ox) * k;
                o[1] = ny + (v[1] - oy) * k;
                return o;
            }, k);
        }
        mapProp(tr.scale, function (v) {
            var o = copyArr(v);
            o[0] *= k; o[1] *= k;
            if (o.length > 2) o[2] *= k;
            return o;
        });
    }

    function isPlain(L) {
        if (L.adjustmentLayer) return true;
        try { if (L.source && L.source.mainSource instanceof SolidSource) return true; } catch (e) {}
        return false;
    }

    function addBlur(layer, amount) {
        var fx = layer.property("ADBE Effect Parade").addProperty("ADBE Gaussian Blur 2");
        try { fx.property("ADBE Gaussian Blur 2-0001").setValue(amount); } catch (e) {}
        try { fx.property("ADBE Gaussian Blur 2-0003").setValue(1); } catch (e) {}
        return fx;
    }

    // Regroupe les éléments en colonnes : deux éléments dont les plages
    // horizontales se chevauchent (avec tolérance) sont dans le même bloc.
    function buildColumns(els, tol) {
        var n = els.length, parent = [], i, j;
        for (i = 0; i < n; i++) parent.push(i);
        function find(x) { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
        for (i = 0; i < n; i++) {
            for (j = i + 1; j < n; j++) {
                var A = els[i].b, B = els[j].b;
                var ov = Math.min(A.r, B.r) - Math.max(A.l, B.l);
                if (ov > Math.max(tol, 0.35 * Math.min(A.r - A.l, B.r - B.l))) parent[find(i)] = find(j);
            }
        }
        var map = {}, cols = [];
        for (i = 0; i < n; i++) {
            var r = find(i);
            if (map[r] === undefined) { map[r] = cols.length; cols.push({ items: [] }); }
            cols[map[r]].items.push(els[i]);
        }
        for (i = 0; i < cols.length; i++) {
            var c = cols[i], l = 1e9, t = 1e9, rr = -1e9, bb = -1e9;
            for (j = 0; j < c.items.length; j++) {
                var b = c.items[j].b;
                if (b.l < l) l = b.l; if (b.t < t) t = b.t;
                if (b.r > rr) rr = b.r; if (b.b > bb) bb = b.b;
            }
            c.l = l; c.t = t; c.r = rr; c.b = bb; c.w = rr - l; c.h = bb - t;
            c.cx = (l + rr) / 2; c.cy = (t + bb) / 2;
        }
        // Ordre de lecture : de gauche à droite (puis de haut en bas).
        cols.sort(function (a, b) { return (a.l - b.l) || (a.t - b.t); });
        return cols;
    }

    /* ------------------------------------------------------------------
       Méthode 1 : Réorganiser
    ------------------------------------------------------------------ */

    // Message d'erreur sûr (certains objets d'erreur d'AE ne se convertissent pas en texte).
    function errText(e) {
        var t = "";
        try { t = e && e.message ? e.message : String(e); } catch (x) { t = "erreur"; }
        try { if (e && e.line) t += " (ligne " + e.line + ")"; } catch (x2) {}
        return t;
    }

    function isStatic(prop) {
        try { return prop.numKeys === 0 && !(prop.canSetExpression && prop.expressionEnabled && prop.expression !== ""); }
        catch (e) { return false; }
    }

    // Regroupe les éléments en bandes : sur l'axe "x" (colonnes) ou "y" (rangées).
    // Deux éléments vont ensemble si leurs étendues se recouvrent nettement sur cet axe.
    function buildBands(els, axis, tol) {
        var n = els.length, par = [], i, j;
        for (i = 0; i < n; i++) par.push(i);
        function find(x) { while (par[x] !== x) { par[x] = par[par[x]]; x = par[x]; } return x; }
        for (i = 0; i < n; i++) {
            for (j = i + 1; j < n; j++) {
                var A = els[i].b, B = els[j].b;
                var a0 = axis === "x" ? A.l : A.t, a1 = axis === "x" ? A.r : A.b;
                var b0 = axis === "x" ? B.l : B.t, b1 = axis === "x" ? B.r : B.b;
                var ov = Math.min(a1, b1) - Math.max(a0, b0);
                // même place à l'écran (souvent à des moments différents) : ils partagent la même case
                var ix = Math.min(A.r, B.r) - Math.max(A.l, B.l), iy = Math.min(A.b, B.b) - Math.max(A.t, B.t);
                var inter = (ix > 0 && iy > 0) ? ix * iy : 0;
                var small = Math.min((A.r - A.l) * (A.b - A.t), (B.r - B.l) * (B.b - B.t));
                if (ov > Math.max(2, 0.35 * Math.min(a1 - a0, b1 - b0)) || inter > 0.2 * small) par[find(i)] = find(j);
            }
        }
        var map = {}, out = [];
        for (i = 0; i < n; i++) {
            var r = find(i);
            if (map[r] === undefined) { map[r] = out.length; out.push({ items: [] }); }
            out[map[r]].items.push(els[i]);
        }
        for (i = 0; i < out.length; i++) {
            var c = out[i], l = 1e9, t = 1e9, rr = -1e9, bb = -1e9;
            for (j = 0; j < c.items.length; j++) {
                var b = c.items[j].b;
                if (b.l < l) l = b.l; if (b.t < t) t = b.t;
                if (b.r > rr) rr = b.r; if (b.b > bb) bb = b.b;
            }
            c.l = l; c.t = t; c.r = rr; c.b = bb; c.w = rr - l; c.h = bb - t;
            c.cx = (l + rr) / 2; c.cy = (t + bb) / 2;
        }
        out.sort(function (a, b) { return axis === "x" ? ((a.l - b.l) || (a.t - b.t)) : ((a.t - b.t) || (a.l - b.l)); });
        return out;
    }

    // Centre horizontalement chaque élément d'un bloc sur l'axe du bloc,
    // sauf s'il partage sa ligne avec un voisin (éléments côte à côte : on n'y touche pas).
    function centerUnits(comp, bd) {
        var it = bd.items, i, j, moved = 0;
        for (i = 0; i < it.length; i++) {
            var A = it[i].b, alone = true;
            for (j = 0; j < it.length && alone; j++) {
                if (i === j) continue;
                var B = it[j].b;
                var oy = Math.min(A.b, B.b) - Math.max(A.t, B.t);
                var ox = Math.min(A.r, B.r) - Math.max(A.l, B.l);
                if (oy > 0.3 * Math.min(A.h, B.h) && ox < 0.35 * Math.min(A.w, B.w)) alone = false;
            }
            if (!alone) continue;
            var ucx = (A.l + A.r) / 2, dx = bd.cx - ucx;
            if (Math.abs(dx) < 2) continue;
            var n = makeGroupNull(comp, "Flip · centrage", ucx, (A.t + A.b) / 2);
            attach(it[i].roots, n);
            n.transform.position.setValue([ucx + dx, (A.t + A.b) / 2]);
            it[i].cnul = n;
            if (!bd.extra) bd.extra = [];
            bd.extra.push(n);
            A.l += dx; A.r += dx;
            moved++;
        }
        if (moved) {
            var l = 1e9, r = -1e9;
            for (i = 0; i < it.length; i++) { l = Math.min(l, it[i].b.l); r = Math.max(r, it[i].b.r); }
            bd.l = l; bd.r = r; bd.w = r - l; bd.cx = (l + r) / 2;
            log("  " + moved + " élément(s) recentré(s) dans « " + (it[0].label || "bloc") + " »");
        }
    }

    // Précompose les calques d'un bloc (taille d'origine) : ce qui sortait du cadre
    // d'origine reste caché, et le bloc devient un seul calque facile à placer et à masquer.
    function precomposeBand(comp, layers, name, warn) {
        try {
            var names = {}, idx = [], i, lockd = [];
            for (i = 0; i < layers.length; i++) { names[layers[i].name] = true; idx.push(layers[i].index); }
            // Expressions qui visent un calque resté dehors : on les redirige vers la comp parente.
            var esc = comp.name.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
            var re = /thisComp\.layer\(\s*"([^"]+)"\s*\)/g;
            var fix = function (g) {
                for (var q = 1; q <= g.numProperties; q++) {
                    var p; try { p = g.property(q); } catch (e) { continue; }
                    if (!p) continue;
                    if (p.propertyType === PropertyType.PROPERTY) {
                        try {
                            if (p.canSetExpression && p.expression && p.expression.indexOf("thisComp.layer(") >= 0) {
                                var ex = p.expression.replace(re, function (all, nm) {
                                    return names[nm] ? all : 'comp("' + esc + '").layer("' + nm + '")';
                                });
                                if (ex !== p.expression) p.expression = ex;
                            }
                        } catch (e2) {}
                    } else fix(p);
                }
            };
            for (i = 0; i < layers.length; i++) {
                try { fix(layers[i]); } catch (e3) {}
                try { if (layers[i].locked) { layers[i].locked = false; lockd.push(layers[i].name); } } catch (e4) {}
            }
            idx.sort(function (a, b) { return a - b; });
            var pc = comp.layers.precompose(idx, name, true);
            var L = comp.layer(idx[0]);
            L.name = name;
            return L;
        } catch (e) {
            log("  précomposition KO (" + name + ") : " + errText(e));
            return null;
        }
    }

    function is3D(L) { try { return !!L.threeDLayer; } catch (e) { return false; } }

    function mulKeys(prop, fn) {
        if (prop.numKeys === 0) { prop.setValue(fn(prop.value)); return; }
        for (var i = 1; i <= prop.numKeys; i++) prop.setValueAtKey(i, fn(prop.keyValue(i)));
    }

    // Scène 3D avec caméra : on ne déplace jamais les calques 3D (la caméra les regarde).
    // Le cadrage se fait par la caméra (zoom + recentrage), les fonds 3D sont agrandis sur place,
    // les calques 2D suivent un Null global.
    function cameraMode(comp, pr, els, bgs, decor, passive, oW, oH, nW, nH, m, o, warn, depth) {
        var i, j, L;
        var safeW = nW - 2 * m, safeH = nH - 2 * m;
        var cover = Math.max(nW / oW, nH / oH);
        log("  scène 3D avec caméra : cadrage par la caméra");

        // 1. Précomps plein écran : converties, posées au même point de la scène
        var rest = [];
        for (i = 0; i < bgs.length; i++) {
            var g = bgs[i], lone = g.members.length === 1 ? g.members[0] : null;
            if (lone && o.deep !== false && depth < 4 &&
                tryFlipPrecomp({ L: lone, locked: lone.locked }, comp, oW, oH, nW, nH, o, warn, depth, is3D(lone))) continue;
            rest.push(g);
        }

        // 2. Contenu à cadrer (éléments mesurés à travers la caméra)
        var box = null;
        for (i = 0; i < els.length; i++) box = unionBox(box, els[i].box);
        var k = 1, ccx = oW / 2, ccy = oH / 2;
        if (box) {
            k = Math.min(1, safeW / (box.r - box.l), safeH / (box.b - box.t));
            ccx = (box.l + box.r) / 2; ccy = (box.t + box.b) / 2;
        }
        log("  zoom caméra x" + k.toFixed(3));

        // 3. Calques 2D : un Null global (centre du contenu -> centre du nouveau cadre)
        var flat = [], flatBg = [];
        function collect2D(units, arr) {
            for (var a = 0; a < units.length; a++)
                for (var b = 0; b < units[a].roots.length; b++)
                    if (!is3D(units[a].roots[b])) arr.push(units[a].roots[b]);
        }
        collect2D(els, flat); collect2D(decor, flat); collect2D(passive, flat);
        collect2D(rest, flatBg);
        var n2d = flat.length ? makeGroupNull(comp, "Flip · calques 2D", ccx, ccy) : null;
        if (n2d) attach(flat, n2d);
        var nbg = flatBg.length ? makeGroupNull(comp, "Flip · fond 2D", oW / 2, oH / 2) : null;
        if (nbg) attach(flatBg, nbg);

        // 4. Nouveau cadre
        comp.width = nW;
        comp.height = nH;
        if (n2d) moveNull(n2d, nW / 2, nH / 2, k);
        if (nbg) moveNull(nbg, nW / 2, nH / 2, cover);

        // 5. Caméras : recentrées sur le contenu, zoom ajusté
        var ox = ccx - oW / 2, oy = ccy - oH / 2;
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if (!(L instanceof CameraLayer)) continue;
            var lk = L.locked; if (lk) L.locked = false;
            try {
                if ((Math.abs(ox) > 1 || Math.abs(oy) > 1) && L.parent == null) {
                    var sh = function (v) { var r = copyArr(v); r[0] += ox; r[1] += oy; return r; };
                    if (!L.transform.position.dimensionsSeparated) mulKeys(L.transform.position, sh);
                    try { mulKeys(L.transform.pointOfInterest, sh); } catch (eP) {}
                }
                if (k < 0.999) {
                    var z = L.property("ADBE Camera Options Group").property("ADBE Camera Zoom");
                    if (isStatic(z) || z.numKeys > 0) mulKeys(z, function (v) { return v * k; });
                    else warn.push("Zoom de « " + L.name + " » piloté par expression : non modifié.");
                }
            } catch (eC) { warn.push("Caméra « " + L.name + " » : " + errText(eC)); }
            if (lk) L.locked = true;
        }

        // 6. Fonds 3D : agrandis sur place pour couvrir le nouveau cadre
        var f3 = cover / k;
        for (i = 0; i < rest.length; i++) {
            for (j = 0; j < rest[i].roots.length; j++) {
                L = rest[i].roots[j];
                if (!is3D(L)) continue;
                var lk2 = L.locked; if (lk2) L.locked = false;
                try { mulKeys(L.transform.scale, function (v) { var r = copyArr(v); r[0] *= f3; r[1] *= f3; return r; }); }
                catch (eS) { warn.push("Fond « " + L.name + " » : " + errText(eS)); }
                if (lk2) L.locked = true;
            }
        }
        return { comp: comp, counts: { el: els.length, bg: bgs.length, blocks: 1 } };
    }

    // Précomp plein écran : on la convertit elle aussi (récursivement) puis on remplace la source,
    // pour que son contenu soit réorganisé au lieu d'être simplement réduit.
    function tryFlipPrecomp(g, comp, oW, oH, nW, nH, o, warn, depth, keepPos) {
        var L = g.L;
        try {
            if (!(L.source instanceof CompItem)) return false;
            var sc = L.source;
            if (Math.abs(sc.width - oW) > 2 || Math.abs(sc.height - oH) > 2) return false;
            var tr = L.transform;
            if (!isStatic(tr.position) || !isStatic(tr.scale) || !isStatic(tr.anchorPoint)) return false;
            if (tr.position.dimensionsSeparated) return false;
            var s = tr.scale.value, a = tr.anchorPoint.value, p = tr.position.value;
            if (Math.abs(s[0] - 100) > 0.5 || Math.abs(s[1] - 100) > 0.5) return false;
            if (Math.abs(a[0] - oW / 2) > 2 || Math.abs(a[1] - oH / 2) > 2) return false;
            if (Math.abs(p[0] - oW / 2) > 2 || Math.abs(p[1] - oH / 2) > 2) return false;
            try { if (Math.abs(tr.rotation.value) > 0.01 || Math.abs(tr.zRotation.value) > 0.01) return false; } catch (eR) {}

            if (!o._cache) o._cache = {};
            var flipped = o._cache[sc.id];
            if (!flipped) {
                log("  -> précomp « " + sc.name + " » convertie aussi");
                var sub = { margin: o.margin, gap: o.gap, maxScale: o.maxScale, bg: o.bg, copy: true, deep: o.deep, clip: o.clip, center: o.center, decor: o.decor, _cache: o._cache };
                flipped = reflowMode(sc, sub, nW, nH, warn, depth + 1).comp;
                o._cache[sc.id] = flipped;
            }
            if (g.locked) L.locked = false;
            L.replaceSource(flipped, false);
            var na = copyArr(a); na[0] = nW / 2; na[1] = nH / 2;
            var np = copyArr(p); np[0] = nW / 2; np[1] = nH / 2;
            L.transform.anchorPoint.setValue(na);
            if (!keepPos) L.transform.position.setValue(np);
            if (g.locked) L.locked = true;
            return true;
        } catch (e) {
            log("  précomp « " + L.name + " » non convertie : " + errText(e));
            return false;
        }
    }

    /* ---------- Mesure fiable : sonde par expression ----------
       Une couche Null temporaire porte deux Point Control dont l'expression
       calcule, via toComp(), la boîte réelle d'un calque dans la comp
       (parentage, expressions, 3D compris). */

    function makeProbe(comp) {
        var p = comp.layers.addNull(comp.duration);
        p.name = "Flip sonde (temporaire)";
        p.property("ADBE Effect Parade").addProperty("ADBE Point Control");
        p.property("ADBE Effect Parade").addProperty("ADBE Point Control");
        return { layer: p };
    }

    function probeExpr(idx, isMax) {
        return "try{var L=thisComp.layer(" + idx + ");var r=L.sourceRectAtTime(time,false);" +
            "var a=L.toComp([r.left,r.top]),b=L.toComp([r.left+r.width,r.top])," +
            "c=L.toComp([r.left,r.top+r.height]),d=L.toComp([r.left+r.width,r.top+r.height]);" +
            (isMax ? "[Math.max(a[0],b[0],c[0],d[0]),Math.max(a[1],b[1],c[1],d[1])]"
                   : "[Math.min(a[0],b[0],c[0],d[0]),Math.min(a[1],b[1],c[1],d[1])]") +
            "}catch(e){" + (isMax ? "[-999999,-999999]" : "[999999,999999]") + "}";
    }

    // Boîte d'un calque sur plusieurs instants (union). null si rien de mesurable.
    function probeLayer(pr, L, times) {
        // Les références de propriétés d'AE expirent vite : on les relit à chaque fois.
        var fxp = pr.layer.property("ADBE Effect Parade");
        var pMin = fxp.property(1).property(1), pMax = fxp.property(2).property(1);
        pMin.expression = probeExpr(L.index, false);
        pMax.expression = probeExpr(L.index, true);
        var u = null;
        for (var i = 0; i < times.length; i++) {
            var a = pMin.valueAtTime(times[i], false), b = pMax.valueAtTime(times[i], false);
            if (!(a[0] < b[0] && a[1] < b[1]) || a[0] > 900000 || b[0] < -900000) continue;
            if (!u) u = { l: a[0], t: a[1], r: b[0], b: b[1] };
            else { u.l = Math.min(u.l, a[0]); u.t = Math.min(u.t, a[1]); u.r = Math.max(u.r, b[0]); u.b = Math.max(u.b, b[1]); }
        }
        return u;
    }

    function unionBox(u, v) {
        if (!v) return u;
        if (!u) return { l: v.l, t: v.t, r: v.r, b: v.b };
        return { l: Math.min(u.l, v.l), t: Math.min(u.t, v.t), r: Math.max(u.r, v.r), b: Math.max(u.b, v.b) };
    }

    function clipBox(u, W, H) {
        if (!u) return null;
        var c = { l: Math.max(u.l, 0), t: Math.max(u.t, 0), r: Math.min(u.r, W), b: Math.min(u.b, H) };
        return (c.r - c.l > 1 && c.b - c.t > 1) ? c : null;
    }

    // Instants "posés" d'un calque : le milieu de sa présence (après les entrées, avant les sorties).
    function sampleTimes(L, comp) {
        var a = Math.max(Math.min(L.inPoint, L.outPoint), 0);
        var b = Math.min(Math.max(L.inPoint, L.outPoint), comp.duration);
        if (b - a < comp.frameDuration) return [Math.max(0, Math.min(comp.time, comp.duration - comp.frameDuration))];
        var f = [0.3, 0.45, 0.6, 0.75], t = [];
        for (var i = 0; i < f.length; i++) t.push(a + (b - a) * f[i]);
        return t;
    }

    function isVisual(L) {
        try {
            if (L instanceof CameraLayer || L instanceof LightLayer) return false;
            if (!L.enabled || L.guideLayer || L.nullLayer || L.adjustmentLayer) return false;
            if (L.hasVideo === false) return false;
            try { if (L.isTrackMatte) return false; } catch (e1) {}
            return true;
        } catch (e) { return false; }
    }

    // Remplace thisComp.width / thisComp.height par les anciennes valeurs dans les expressions
    // de la copie, pour qu'elles gardent leur sens après le changement de taille.
    function freezeCompSize(comp, oW, oH) {
        var n = 0;
        function walk(g) {
            for (var i = 1; i <= g.numProperties; i++) {
                var p;
                try { p = g.property(i); } catch (e) { continue; }
                if (!p) continue;
                if (p.propertyType === PropertyType.PROPERTY) {
                    try {
                        if (p.canSetExpression && p.expression && /thisComp\.(width|height)/.test(p.expression)) {
                            p.expression = p.expression.replace(/thisComp\.width/g, "(" + oW + ")").replace(/thisComp\.height/g, "(" + oH + ")");
                            n++;
                        }
                    } catch (e2) {}
                } else {
                    walk(p);
                }
            }
        }
        for (var i = 1; i <= comp.numLayers; i++) {
            try { walk(comp.layer(i)); } catch (e) {}
        }
        if (n) log("  " + n + " expression(s) thisComp.width/height figée(s)");
    }

    // Null "identité" : ancrage = position = (cx, cy), échelle 100 %.
    // Y rattacher des calques ne change rien à l'image ; on le déplace ensuite.
    function makeGroupNull(comp, name, cx, cy) {
        var n = comp.layers.addNull(comp.duration);
        n.name = name;
        n.label = 9;
        n.transform.anchorPoint.setValue([cx, cy]);
        n.transform.position.setValue([cx, cy]);
        return n;
    }

    function attach(layers, nul) {
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i], lk = false;
            try {
                lk = L.locked;
                if (lk) L.locked = false;
                L.parent = nul;
            } catch (e) { log("  rattachement KO " + L.name + " : " + errText(e)); }
            try { if (lk) L.locked = true; } catch (e2) {}
        }
    }

    function moveNull(nul, x, y, k) {
        nul.transform.position.setValue([x, y]);
        nul.transform.scale.setValue([k * 100, k * 100]);
    }

    function reflowMode(src, o, nW, nH, warn, depth) {
        depth = depth || 0;
        var comp = src;
        if (o.copy) {
            comp = src.duplicate();
            comp.name = src.name + " - Flip " + nW + "x" + nH;
        }
        var oW = comp.width, oH = comp.height;
        var m = Math.round(Math.min(nW, nH) * o.margin / 100);
        var safeW = nW - 2 * m, safeH = nH - 2 * m;
        log("Comp " + comp.name + " " + oW + "x" + oH + " -> " + nW + "x" + nH + " marge=" + m);

        freezeCompSize(comp, oW, oH);

        var pr = makeProbe(comp);
        var i, j, L;

        // 1. Calques et groupes (parentage + caches de suivi = un seul groupe)
        var layers = [];
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if (L === pr.layer || L.index === pr.layer.index) continue;
            if (L instanceof CameraLayer) continue;
            if (L instanceof LightLayer) continue;
            layers.push(L);
        }
        var uf = {};
        function find(k) { while (uf[k] !== k) { uf[k] = uf[uf[k]]; k = uf[k]; } return k; }
        function join(a, b) { var x = find(a), y = find(b); if (x !== y) uf[x] = y; }
        for (i = 0; i < layers.length; i++) uf[layers[i].index] = layers[i].index;
        for (i = 0; i < layers.length; i++) {
            L = layers[i];
            try {
                var root = L;
                while (root.parent != null) root = root.parent;
                if (uf[root.index] !== undefined) join(L.index, root.index);
            } catch (e) {}
            try {
                if (L.trackMatteType !== TrackMatteType.NO_TRACK_MATTE) {
                    var ml = null;
                    try { ml = L.trackMatteLayer; } catch (e3) {}
                    if (!ml && L.index > 1) ml = comp.layer(L.index - 1);
                    if (ml && uf[ml.index] !== undefined) join(L.index, ml.index);
                }
            } catch (e2) {}
        }
        var unitsMap = {}, units = [];
        for (i = 0; i < layers.length; i++) {
            L = layers[i];
            var r = find(L.index);
            if (!unitsMap[r]) { unitsMap[r] = { members: [], roots: [], box: null }; units.push(unitsMap[r]); }
            unitsMap[r].members.push(L);
            if (L.parent == null) unitsMap[r].roots.push(L);
        }

        // 2. Mesure de la partie VISIBLE de chaque groupe
        var els = [], bgs = [], passive = [], decor = [];
        for (i = 0; i < units.length; i++) {
            var u = units[i], raw = null, vis = 0;
            for (j = 0; j < u.members.length; j++) {
                L = u.members[j];
                if (!isVisual(L)) continue;
                vis++;
                try { raw = unionBox(raw, probeLayer(pr, L, sampleTimes(L, comp))); }
                catch (e) { log("  mesure KO " + L.name + " : " + errText(e)); }
            }
            var lone = u.members.length === 1 ? u.members[0] : null;
            if (lone && lone.adjustmentLayer) { u.kind = "plain"; u.box = { l: 0, t: 0, r: oW, b: oH }; bgs.push(u); continue; }
            if (!vis) continue; // contrôleurs, nulls sans enfants : on n'y touche pas
            u.box = clipBox(raw, oW, oH);
            var names = [];
            for (j = 0; j < u.roots.length && j < 3; j++) names.push(u.roots[j].name);
            u.label = names.join(", ") + (u.members.length > 1 ? " (+" + (u.members.length - 1) + ")" : "");
            if (!u.box) { passive.push(u); log("  " + u.label + " : hors champ"); continue; }
            var bw = u.box.r - u.box.l, bh = u.box.b - u.box.t;
            var full = bw >= oW * 0.9 && bh >= oH * 0.9 && !(lone && lone instanceof TextLayer);
            var hasText = false;
            for (j = 0; j < u.members.length; j++) if (u.members[j] instanceof TextLayer) hasText = true;
            var tolB = Math.min(oW, oH) * 0.02;
            var bleeds = raw.l < -tolB || raw.t < -tolB || raw.r > oW + tolB || raw.b > oH + tolB;
            if (!full && bleeds && !hasText && o.decor !== false) {
                u.kind = "decor";
                decor.push(u);
                log("  " + u.label + " : décor qui déborde du cadre");
                continue;
            }
            if (full) {
                u.kind = (lone && isPlain(lone)) ? "plain" : "media";
                bgs.push(u);
            } else {
                u.kind = "el";
                u.b = { l: u.box.l, t: u.box.t, r: u.box.r, b: u.box.b, w: bw, h: bh };
                els.push(u);
            }
            log("  " + u.label + " [" + Math.round(u.box.l) + "," + Math.round(u.box.t) + " " + Math.round(bw) + "x" + Math.round(bh) + "] " + u.kind);
        }

        var camHere = false;
        for (i = 1; i <= comp.numLayers; i++) { try { if (comp.layer(i) instanceof CameraLayer && comp.layer(i).enabled) camHere = true; } catch (e) {} }
        if (camHere) {
            var cres = cameraMode(comp, pr, els, bgs, decor, passive, oW, oH, nW, nH, m, o, warn, depth);
            try { pr.layer.remove(); } catch (e) {}
            return cres;
        }

        // 3. Groupes (Nulls identité) créés AVANT le changement de taille
        var gfit = Math.min(nW / oW, nH / oH);
        var bgPlan = [];
        for (i = 0; i < bgs.length; i++) {
            var g = bgs[i];
            var lone2 = g.members.length === 1 ? g.members[0] : null;
            if (lone2 && o.deep !== false && depth < 4 &&
                tryFlipPrecomp({ L: lone2, locked: lone2.locked }, comp, oW, oH, nW, nH, o, warn, depth)) continue;
            var cx = (g.box.l + g.box.r) / 2, cy = (g.box.t + g.box.b) / 2;
            var gw = g.box.r - g.box.l, gh = g.box.b - g.box.t;
            var cover = Math.max(nW / gw, nH / gh), fit = Math.min(nW / gw, nH / gh);
            if (g.kind === "plain" || o.bg === 2) {
                var n1 = makeGroupNull(comp, "Flip · fond", cx, cy);
                attach(g.roots, n1);
                bgPlan.push({ n: n1, k: cover });
            } else {
                if (o.bg === 0 && lone2) {
                    try {
                        if (lone2.locked) lone2.locked = false;
                        var d = lone2.duplicate();
                        d.moveAfter(lone2);
                        d.name = lone2.name + " (Flip fond flou)";
                        var n2 = makeGroupNull(comp, "Flip · fond flou", cx, cy);
                        attach([d], n2);
                        addBlur(d, Math.round(60 * Math.max(nW, nH) / 1920));
                        bgPlan.push({ n: n2, k: cover * 1.05 });
                    } catch (e) { log("  fond flou KO : " + errText(e)); }
                }
                var n3 = makeGroupNull(comp, "Flip · média", cx, cy);
                attach(g.roots, n3);
                bgPlan.push({ n: n3, k: fit });
            }
        }

        // 4. Blocs. Sens de rangement selon le format visé :
        //    cible plus haute -> colonnes empilées de haut en bas ;
        //    cible plus large -> rangées posées de gauche à droite.
        var vertical = (nH / nW) >= (oH / oW);
        var bands = buildBands(els, vertical ? "x" : "y", (vertical ? oW : oH) * 0.03);
        var hasCam = false;
        for (i = 1; i <= comp.numLayers; i++) { try { if (comp.layer(i) instanceof CameraLayer) hasCam = true; } catch (e) {} }
        var usePrecomp = !hasCam && o.clip !== false;
        if (hasCam) log("  caméra présente : blocs par Nulls (sans précomp)");

        // Décor qui déborde : chaque forme garde sa place relative (un coin reste un coin).
        for (i = 0; i < decor.length; i++) {
            var dc = decor[i];
            dc.cx = (dc.box.l + dc.box.r) / 2; dc.cy = (dc.box.t + dc.box.b) / 2;
            dc.nul = makeGroupNull(comp, "Flip · décor", dc.cx, dc.cy);
            attach(dc.roots, dc.nul);
        }
        // Éléments hors champ aux instants mesurés : ils suivent le cadre d'origine, masqués à ses bords.
        if (passive.length) bands.push({ items: passive, passive: true, l: 0, t: 0, r: oW, b: oH, w: oW, h: oH, cx: oW / 2, cy: oH / 2 });

        for (i = 0; i < bands.length; i++) {
            var bd = bands[i], lys = [];
            if (o.center !== false && !bd.passive) centerUnits(comp, bd);
            for (j = 0; j < bd.items.length; j++) lys = lys.concat(bd.items[j].members);
            if (bd.extra) lys = lys.concat(bd.extra);
            bd.layers = lys;
            bd.name = "Flip · bloc " + (i + 1) + " - " + (bd.items[0].label || "").substr(0, 40);
            if (usePrecomp) {
                bd.layer = precomposeBand(comp, lys, bd.name, warn);
                if (bd.layer) {
                    bd.layer.transform.anchorPoint.setValue([bd.cx, bd.cy]);
                    bd.layer.transform.position.setValue([bd.cx, bd.cy]);
                    continue;
                }
            }
            bd.nul = makeGroupNull(comp, bd.name, bd.cx, bd.cy);
            var rts = [];
            for (j = 0; j < bd.items.length; j++) rts = rts.concat(bd.items[j].cnul ? [bd.items[j].cnul] : bd.items[j].roots);
            attach(rts, bd.nul);
        }

        // 5. Nouveau cadre
        comp.width = nW;
        comp.height = nH;

        for (i = 0; i < bgPlan.length; i++) moveNull(bgPlan[i].n, nW / 2, nH / 2, bgPlan[i].k);
        var kDecor = Math.sqrt((nW * nH) / (oW * oH));
        for (i = 0; i < decor.length; i++) moveNull(decor[i].nul, decor[i].cx / oW * nW, decor[i].cy / oH * nH, kDecor);

        // 6. Placement : blocs alignés sur l'axe principal, centrés sur l'autre, même échelle pour tous
        var main = [], gfitAll = Math.min(nW / oW, nH / oH);
        for (i = 0; i < bands.length; i++) if (!bands[i].passive) main.push(bands[i]);
        if (main.length) {
            var gapPx = Math.round(Math.min(nW, nH) * o.gap / 100);
            var mainLen = vertical ? safeH : safeW, crossLen = vertical ? safeW : safeH;
            var sumMain = 0, maxCross = 0;
            for (i = 0; i < main.length; i++) {
                sumMain += vertical ? main[i].h : main[i].w;
                maxCross = Math.max(maxCross, vertical ? main[i].w : main[i].h);
            }
            var gapsTotal = gapPx * (main.length - 1);
            var k = Math.min((mainLen - gapsTotal) / sumMain, crossLen / maxCross, o.maxScale);
            if (!(k > 0)) k = gfitAll;
            var used = sumMain * k + gapsTotal;
            var pos = (vertical ? nH : nW) / 2 - used / 2;
            log((vertical ? "Colonnes" : "Rangées") + "=" + main.length + " echelle=" + k.toFixed(3));
            for (i = 0; i < main.length; i++) {
                var b2 = main[i], len = (vertical ? b2.h : b2.w) * k;
                b2.k = k;
                b2.tx = vertical ? nW / 2 : pos + len / 2;
                b2.ty = vertical ? pos + len / 2 : nH / 2;
                // Case du bloc : jusqu'à mi-chemin des voisins, bords du cadre aux extrémités
                var s0 = (i === 0) ? 0 : pos - gapPx / 2;
                var s1 = (i === main.length - 1) ? (vertical ? nH : nW) : pos + len + gapPx / 2;
                b2.slot = vertical ? { l: 0, t: s0, r: nW, b: s1 } : { l: s0, t: 0, r: s1, b: nH };
                pos += len + gapPx;
                placeBand(b2);
                log("  " + b2.name);
            }
        }
        for (i = 0; i < bands.length; i++) {
            if (!bands[i].passive) continue;
            var pb = bands[i];
            pb.k = gfitAll; pb.tx = nW / 2; pb.ty = nH / 2;
            pb.slot = { l: nW / 2 - oW * gfitAll / 2, t: nH / 2 - oH * gfitAll / 2, r: nW / 2 + oW * gfitAll / 2, b: nH / 2 + oH * gfitAll / 2 };
            placeBand(pb);
        }

        function placeBand(b) {
            var tgt = b.layer || b.nul;
            tgt.transform.position.setValue([b.tx, b.ty]);
            tgt.transform.scale.setValue([b.k * 100, b.k * 100]);
            if (b.layer) {
                // Masque = la case du bloc, exprimée dans l'espace du calque précomp
                var inv = function (x, y) { return [b.cx + (x - b.tx) / b.k, b.cy + (y - b.ty) / b.k]; };
                try {
                    var mk = b.layer.property("ADBE Mask Parade").addProperty("ADBE Mask Atom");
                    mk.name = "Flip · case";
                    var sh = new Shape();
                    sh.vertices = [inv(b.slot.l, b.slot.t), inv(b.slot.r, b.slot.t), inv(b.slot.r, b.slot.b), inv(b.slot.l, b.slot.b)];
                    sh.closed = true;
                    mk.property("ADBE Mask Shape").setValue(sh);
                } catch (e) { log("  masque KO : " + errText(e)); }
            }
        }

        // 7. Contrôle : chaque bloc re-mesuré (sans masque) et ramené dans sa case si besoin
        for (i = 0; i < main.length; i++) {
            var c3 = main[i], nb = null;
            if (c3.layer) {
                try { nb = probeLayer(pr, c3.layer, [comp.duration * 0.5]); } catch (e) {}
                // la boîte d'un calque précomp = son cadre entier : on mesure plutôt le contenu
                nb = null;
                var bx0 = c3.tx - c3.w * c3.k / 2, by0 = c3.ty - c3.h * c3.k / 2;
                nb = { l: bx0, t: by0, r: bx0 + c3.w * c3.k, b: by0 + c3.h * c3.k };
            } else {
                for (j = 0; j < c3.layers.length; j++) {
                    if (!isVisual(c3.layers[j])) continue;
                    try { nb = unionBox(nb, probeLayer(pr, c3.layers[j], sampleTimes(c3.layers[j], comp))); } catch (e) {}
                }
            }
            if (!nb) continue;
            var lim = { l: Math.max(c3.slot.l, m), t: Math.max(c3.slot.t, m), r: Math.min(c3.slot.r, nW - m), b: Math.min(c3.slot.b, nH - m) };
            var w2 = nb.r - nb.l, h2 = nb.b - nb.t;
            var f = Math.min(1, (lim.r - lim.l) / w2, (lim.b - lim.t) / h2);
            if (f < 0.999) {
                c3.k *= f;
                var tg = c3.layer || c3.nul;
                tg.transform.scale.setValue([c3.k * 100, c3.k * 100]);
                log("  recadré : " + c3.name + " (x" + f.toFixed(2) + ")");
            }
        }

        try { pr.layer.remove(); } catch (e) {}
        return { comp: comp, counts: { el: els.length, bg: bgs.length, blocks: bands.length } };
    }

    /* ------------------------------------------------------------------
       Méthode 2 : Ajuster tout + fond flou
    ------------------------------------------------------------------ */

    function fitMode(src, o, nW, nH) {
        var c = app.project.items.addComp(src.name + " - Flip " + nW + "x" + nH,
            nW, nH, src.pixelAspect, src.duration, src.frameRate);
        c.bgColor = src.bgColor;
        c.displayStartTime = src.displayStartTime;
        var m = Math.round(Math.min(nW, nH) * o.margin / 100);
        var fit = Math.min((nW - 2 * m) / src.width, (nH - 2 * m) / src.height);
        var cover = Math.max(nW / src.width, nH / src.height) * 1.05;

        var bg = c.layers.add(src);
        bg.name = "Flip fond flou";
        bg.transform.scale.setValue([cover * 100, cover * 100]);
        addBlur(bg, Math.round(60 * Math.max(nW, nH) / 1920));

        var fg = c.layers.add(src);
        fg.name = "Flip contenu";
        fg.transform.scale.setValue([fit * 100, fit * 100]);
        return { comp: c, counts: { el: 1, bg: 1, blocks: 1 } };
    }

    /* ------------------------------------------------------------------
       Lancement
    ------------------------------------------------------------------ */

    // Retourne { ok, status, warn[] }. Avec o.quiet, aucune alerte n'est affichée.
    function run(o, setStatus) {
        LOG = [];
        var quiet = !!o.quiet;
        function say(msg) { if (!quiet) alert(msg); }
        var result = { ok: false, status: "", warn: [] };
        setStatus = setStatus || function () {};
        var comp = o.comp || app.project.activeItem;
        if (!(comp && comp instanceof CompItem)) {
            result.status = "Ouvre ou sélectionne une composition.";
            say("Flip : " + result.status);
            return result;
        }
        var f = FORMATS[o.fmt];
        var nW = f.w ? f.w : comp.height;
        var nH = f.h ? f.h : comp.width;
        if (nW === comp.width && nH === comp.height) {
            result.status = "La composition est déjà au format " + nW + " x " + nH + ".";
            say("Flip : " + result.status);
            return result;
        }
        var warn = [];
        app.beginUndoGroup("Flip " + nW + "x" + nH);
        try {
            var res = (o.mode === "fit") ? fitMode(comp, o, nW, nH) : reflowMode(comp, o, nW, nH, warn);
            try { res.comp.openInViewer(); } catch (e) {}
            $.global.FLIP_LAST_COMP = res.comp;
            result.ok = true;
            result.status = "OK " + nW + "x" + nH + " : " + res.counts.el + " élément(s) en " + res.counts.blocks +
                      " bloc(s), " + res.counts.bg + " fond(s)" + (warn.length ? " - " + warn.length + " alerte(s)" : "");
            setStatus(result.status);
        } catch (err) {
            result.status = "Erreur : " + errText(err);
            log("ERREUR GLOBALE : " + result.status);
            say("Flip - " + result.status);
            setStatus("Erreur.");
        } finally {
            app.endUndoGroup();
            writeLog();
        }
        result.warn = warn;
        if (warn.length) {
            var shown = warn.slice(0, 12);
            if (warn.length > 12) shown.push("... et " + (warn.length - 12) + " autre(s).");
            say("Flip - à vérifier :\n\n" + shown.join("\n"));
        }
        return result;
    }

    /* ------------------------------------------------------------------
       Interface
    ------------------------------------------------------------------ */

    function slider(parent, label, min, max, val, dec) {
        var g = parent.add("group");
        g.alignChildren = ["left", "center"];
        var st = g.add("statictext", undefined, label);
        st.preferredSize.width = 130;
        var sl = g.add("slider", undefined, val, min, max);
        sl.preferredSize.width = 110;
        var et = g.add("edittext", undefined, val.toFixed(dec));
        et.characters = 4;
        sl.onChanging = function () { et.text = sl.value.toFixed(dec); };
        et.onChange = function () {
            var v = parseFloat(et.text);
            if (isNaN(v)) v = val;
            v = Math.max(min, Math.min(max, v));
            sl.value = v; et.text = v.toFixed(dec);
        };
        return { get: function () { return parseFloat(et.text); } };
    }

    function buildUI(thisObj) {
        var win = (thisObj instanceof Panel) ? thisObj
            : new Window("palette", NAME + " " + VERSION, undefined, { resizeable: true });
        win.orientation = "column";
        win.alignChildren = ["fill", "top"];
        win.spacing = 8;
        win.margins = 12;

        var head = win.add("statictext", undefined, "FLIP " + VERSION + " - changer de format sans rien perdre");
        try { head.graphics.font = ScriptUI.newFont("dialog", "BOLD", 13); } catch (e) {}

        var pF = win.add("panel", undefined, "Format cible");
        pF.alignChildren = ["fill", "top"];
        pF.margins = [10, 15, 10, 10];
        var labels = [];
        for (var i = 0; i < FORMATS.length; i++) labels.push(FORMATS[i].label);
        var ddFmt = pF.add("dropdownlist", undefined, labels);
        ddFmt.selection = 1;

        var pM = win.add("panel", undefined, "Méthode");
        pM.alignChildren = ["left", "top"];
        pM.margins = [10, 15, 10, 10];
        var rbReflow = pM.add("radiobutton", undefined, "Réorganiser (empile et centre les éléments)");
        var rbFit = pM.add("radiobutton", undefined, "Ajuster tout (comp entière centrée + fond flou)");
        rbReflow.value = true;

        var pS = win.add("panel", undefined, "Réglages");
        pS.alignChildren = ["fill", "top"];
        pS.margins = [10, 15, 10, 10];
        var sMargin = slider(pS, "Marge de sécurité (%)", 0, 20, 6, 0);

        var pR = win.add("panel", undefined, "Réorganiser");
        pR.alignChildren = ["fill", "top"];
        pR.margins = [10, 15, 10, 10];
        var sGap = slider(pR, "Espace entre blocs (%)", 0, 30, 8, 0);
        var sMax = slider(pR, "Agrandissement max (x)", 0.5, 3, 1.5, 2);
        var gBg = pR.add("group");
        gBg.add("statictext", undefined, "Médias plein écran :");
        var ddBg = gBg.add("dropdownlist", undefined, BG_MODES);
        ddBg.selection = 0;
        var cbCopy = pR.add("checkbox", undefined, "Travailler sur une copie (original intact)");
        cbCopy.value = true;

        function refresh() { pR.enabled = rbReflow.value; }
        rbReflow.onClick = refresh;
        rbFit.onClick = refresh;

        var gB = win.add("group");
        gB.alignChildren = ["fill", "center"];
        var btn = gB.add("button", undefined, "FLIP !");
        btn.preferredSize.height = 32;
        var help = gB.add("button", undefined, "?");
        help.preferredSize.width = 30;

        var status = win.add("statictext", undefined, "Prêt.", { truncate: "end" });
        status.preferredSize.width = 330;

        btn.onClick = function () {
            run({
                fmt: ddFmt.selection.index,
                mode: rbFit.value ? "fit" : "reflow",
                margin: sMargin.get(),
                gap: sGap.get(),
                maxScale: sMax.get(),
                bg: ddBg.selection.index,
                copy: cbCopy.value
            }, function (s) { status.text = s; });
        };

        help.onClick = function () {
            alert("FLIP " + VERSION + "\n\n" +
                "1. Ouvre la composition à convertir.\n" +
                "2. Choisis le format cible.\n" +
                "3. Réorganiser : les éléments sont groupés en blocs selon leur\n" +
                "   position, puis empilés et centrés dans le nouveau cadre.\n" +
                "   Les médias plein écran restent entiers.\n" +
                "   Ajuster tout : la comp entière est centrée sur un fond flou.\n" +
                "4. FLIP ! (annulable avec Cmd/Ctrl + Z).\n\n" +
                "Astuce : parente les éléments qui vont ensemble à un Null\n" +
                "pour qu'ils restent groupés.");
        };

        refresh();
        win.onResizing = win.onResize = function () { this.layout.resize(); };
        win.layout.layout(true);
        return win;
    }

    // Mode bibliothèque (utilisé par le panneau du plugin) :
    // expose Flip_run(options) qui renvoie "OK|ERR" + statut + alertes, une par ligne.
    if ($.global.FLIP_AS_LIB) {
        $.global.Flip_run = function (opt) {
          try {
            opt = opt || {};
            var r = run({
                fmt: opt.fmt !== undefined ? opt.fmt : 1, mode: opt.mode || "reflow",
                margin: opt.margin !== undefined ? opt.margin : 6, gap: opt.gap !== undefined ? opt.gap : 8,
                maxScale: opt.maxScale || 1.5, bg: opt.bg !== undefined ? opt.bg : 2,
                copy: opt.copy !== undefined ? opt.copy : true, deep: opt.deep !== undefined ? opt.deep : true, clip: opt.clip !== undefined ? opt.clip : true, center: opt.center !== undefined ? opt.center : true, quiet: true
            });
            return (r.ok ? "OK" : "ERR") + "\n" + r.status + (r.warn.length ? "\n" + r.warn.join("\n") : "");
          } catch (eRun) {
            try { app.endUndoGroup(); } catch (eU) {}
            return "ERR\nErreur : " + errText(eRun);
          }
        };
        $.global.Flip_info = function () {
            var c = app.project ? app.project.activeItem : null;
            if (c && c instanceof CompItem) return c.name + "\n" + c.width + " x " + c.height;
            return "";
        };
        return;
    }

    // Mode sans interface (tests / automatisation) : définir FLIP_HEADLESS
    // avec les options avant d'évaluer ce fichier.
    if (typeof FLIP_HEADLESS !== "undefined" && FLIP_HEADLESS) {
        var hs = FLIP_HEADLESS;
        FLIP_HEADLESS = null;
        LOG_PATH = hs.logPath || null;
        run({
            fmt: hs.fmt !== undefined ? hs.fmt : 1, mode: hs.mode || "reflow",
            margin: hs.margin !== undefined ? hs.margin : 6, gap: hs.gap !== undefined ? hs.gap : 8,
            maxScale: hs.maxScale || 1.5, bg: hs.bg !== undefined ? hs.bg : 2, copy: true, comp: hs.comp
        }, function (s) { log("STATUS " + s); });
        if (hs.pngDir && hs.comp && $.global.FLIP_LAST_COMP) {
            try {
                var tPng = hs.pngTime !== undefined ? hs.pngTime : 5;
                hs.comp.saveFrameToPng(tPng, new File(hs.pngDir + "/avant.png"));
                $.global.FLIP_LAST_COMP.saveFrameToPng(tPng, new File(hs.pngDir + "/apres.png"));
                log("PNG ok");
            } catch (e) { log("PNG KO " + e); }
        }
        writeLog();
        return;
    }

    var ui = buildUI(thisObj);
    if (ui instanceof Window) { ui.center(); ui.show(); }

})(this);
