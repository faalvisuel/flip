@echo off
chcp 65001 >nul
REM Installe le plugin Flip pour After Effects (Windows)
cd /d "%~dp0"
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.flip.aepanel"
if not exist "Flip.zxp" (echo Flip.zxp introuvable a cote de cet installeur. & pause & exit /b 1)
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"
copy /y "Flip.zxp" "%TEMP%\flip_install.zip" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force -Path $env:TEMP\flip_install.zip -DestinationPath $env:APPDATA\Adobe\CEP\extensions\com.flip.aepanel"
del "%TEMP%\flip_install.zip" >nul
if exist "%DEST%\CSXS\manifest.xml" (echo. & echo Flip est installe. & echo Redemarre After Effects, puis ouvre : Fenetre ^> Extensions ^> Flip) else (echo Echec de l installation.)
echo.
pause
